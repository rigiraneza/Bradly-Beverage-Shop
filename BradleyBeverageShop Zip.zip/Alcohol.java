
public class Alcohol extends Beverage{

	    private boolean weekend;

	    public Alcohol(String name, Sizes size, boolean weekend) {
	        super(name, Types.Alcohol, size);
	        this.weekend = weekend;
	    }

	    
	    public double calcPrice() {
	        double price = addSizePrice();
	        if (weekend) price += 0.6;
	        return price;
	    }

	    
	    public String toString() {
	        return super.toString() + (weekend ? " (Weekend special)" : "") + " | Price: $" + calcPrice();
	    }

}
