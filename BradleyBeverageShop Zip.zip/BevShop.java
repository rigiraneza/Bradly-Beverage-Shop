import java.util.ArrayList;
import java.util.List;

public class BevShop implements BevShopInterface {

	    private List<Order> orders;
	    private Order currentOrder;

	    public BevShop() {
	        orders = new ArrayList<>();
	    }

	    
	    public void startNewOrder(Days day, Customer customer) {
	        currentOrder = new Order(day, customer);
	        orders.add(currentOrder);
	    }

	    
	    public void addCoffeeToOrder(String name, Sizes size, boolean extraShot, boolean extraSyrup) {
	        if (currentOrder != null) {
	            currentOrder.addNewBeverage(name, size, extraShot, extraSyrup);
	        }
	    }

	    
	    public void addSmoothieToOrder(String name, Sizes size, int numOfFruits, boolean proteinPowder) {
	        if (currentOrder != null) {
	            currentOrder.addNewBeverage(name, size, numOfFruits, proteinPowder);
	        }
	    }

	    
	    public void addAlcoholToOrder(String name, Sizes size, boolean weekend) {
	        if (currentOrder != null) {
	            currentOrder.addNewBeverage(name, size, weekend);
	        }
	    }

	    public double getCurrentOrderTotalPrice() {
	        if (currentOrder != null) {
	            return currentOrder.getTotalPrice();
	        }
	        return 0;
	    }

	    public double getTotalSales() {
	        return orders.stream().mapToDouble(Order::getTotalPrice).sum();
	    }

	    
	    public String toString() {
	        StringBuilder sb = new StringBuilder();
	        for (Order order : orders) {
	            sb.append(order).append("\n");
	        }
	        return sb.toString();
	    }


		@Override
		public boolean isValidTime(int time) {
			// TODO Auto-generated method stub
			return false;
		}


		@Override
		public int getMaxNumOfFruits() {
			// TODO Auto-generated method stub
			return 0;
		}


		@Override
		public int getMinAgeForAlcohol() {
			// TODO Auto-generated method stub
			return 0;
		}


		@Override
		public boolean isMaxFruit(int numOfFruits) {
			// TODO Auto-generated method stub
			return false;
		}


		@Override
		public int getMaxOrderForAlcohol() {
			// TODO Auto-generated method stub
			return 0;
		}


		@Override
		public boolean isEligibleForMore() {
			// TODO Auto-generated method stub
			return false;
		}


		@Override
		public int getNumOfAlcoholDrink() {
			// TODO Auto-generated method stub
			return 0;
		}


		@Override
		public boolean isValidAge(int age) {
			// TODO Auto-generated method stub
			return false;
		}


		@Override
		public void startNewOrder(int time, Days day, String customerName, int customerAge) {
			// TODO Auto-generated method stub
			
		}


		@Override
		public void processCoffeeOrder(String bevName, Sizes size, boolean extraShot, boolean extraSyrup) {
			// TODO Auto-generated method stub
			
		}


		@Override
		public void processAlcoholOrder(String bevName, Sizes size) {
			// TODO Auto-generated method stub
			
		}


		@Override
		public void processSmoothieOrder(String bevName, Sizes size, int numOfFruits, boolean addProtein) {
			// TODO Auto-generated method stub
			
		}


		@Override
		public int findOrder(int orderNo) {
			// TODO Auto-generated method stub
			return 0;
		}


		@Override
		public double totalOrderPrice(int orderNo) {
			// TODO Auto-generated method stub
			return 0;
		}


		@Override
		public double totalMonthlySale() {
			// TODO Auto-generated method stub
			return 0;
		}


		@Override
		public int totalNumOfMonthlyOrders() {
			// TODO Auto-generated method stub
			return 0;
		}


		@Override
		public Order getCurrentOrder() {
			// TODO Auto-generated method stub
			return null;
		}


		@Override
		public Order getOrderAtIndex(int index) {
			// TODO Auto-generated method stub
			return null;
		}


		@Override
		public void sortOrders() {
			// TODO Auto-generated method stub
			
		}


}
