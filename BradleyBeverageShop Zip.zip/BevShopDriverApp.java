import java.util.Scanner;


public class BevShopDriverApp {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        BevShop shop = new BevShop();
	        System.out.println("The current order in process can have at most 3 alcoholic beverages.");
	        System.out.println("The minimum age to order alcohol drink is 21");
	        
	        boolean running = true;
	        while (running) {
	            System.out.println("\nStart please a new order: ");
	            System.out.print("Would you please enter your name: ");
	            String name = scanner.nextLine();
	            
	            System.out.print("Would you please enter your age: ");
	            int age = Integer.parseInt(scanner.nextLine());
	            Customer customer = new Customer(name, age);
	            
	            shop.startNewOrder(Days.Thursday, customer); 
	            
	            if (age >= 21) {
	                System.out.println("Your age is above 20 and you are eligible to order alcohol");
	                int alcoholCount = 0;
	                while (alcoholCount < 3) {
	                    System.out.print("Would you please add an alcohol drink (yes/no): ");
	                    String response = scanner.nextLine();
	                    if (response.equalsIgnoreCase("yes")) {
	                        shop.addAlcoholToOrder("Whisky", Sizes.Large, false);  
	                        alcoholCount++;
	                        System.out.println("The current order of drinks is " + alcoholCount);
	                        System.out.println("The Total Price on the Order: " + shop.getCurrentOrderTotalPrice());
	                        if (alcoholCount == 3) {
	                            System.out.println("You have a maximum alcohol drinks for this order");
	                            break;
	                        }
	                    } else {
	                        break;
	                    }
	                }
	            } else {
	                System.out.println("Your Age is not appropriate for alcohol drink!!");
	            }
	            
	            System.out.print("Would you please add a SMOOTHIE to your order (yes/no): ");
	            if (scanner.nextLine().equalsIgnoreCase("yes")) {
	                shop.addSmoothieToOrder("Berry Delight", Sizes.Medium, 2, true);
	                System.out.println("The Total Price on the Order: " + shop.getCurrentOrderTotalPrice());
	            }
	            
	            System.out.print("Would you please add a COFFEE to your order (yes/no): ");
	            if (scanner.nextLine().equalsIgnoreCase("yes")) {
	                shop.addCoffeeToOrder("Cappuccino", Sizes.Small, true, false);
	                System.out.println("The Total Price on the Order: " + shop.getCurrentOrderTotalPrice());
	            }
	            
	            System.out.print("Do you want to start a new order? (yes/no): ");
	            running = scanner.nextLine().equalsIgnoreCase("yes");
	        }
	        
	        System.out.println("\nFinal summary of all orders:");
	        System.out.println(shop);
	        System.out.println("Total amount for all Orders: " + shop.getTotalSales());
	        
	        scanner.close();
	    }

}
