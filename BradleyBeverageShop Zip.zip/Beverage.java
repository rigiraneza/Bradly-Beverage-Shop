
public abstract class Beverage {
	
	    protected String name;
	    protected Types type;
	    protected Sizes size;
	    protected final double BASE_PRICE = 2.0;
	    protected final double SIZE_PRICE = 0.5;

	    public Beverage(String name, Types type, Sizes size) {
	        this.name = name;
	        this.type = type;
	        this.size = size;
	    }

	    public double addSizePrice() {
	        switch (size) {
	            case Small:
	                return BASE_PRICE;
	            case Medium:
	                return BASE_PRICE + SIZE_PRICE;
	            case Large:
	                return BASE_PRICE + 2 * SIZE_PRICE;
	            default:
	                return BASE_PRICE;
	        }
	    }

	    public abstract double calcPrice();

	    
	    public String toString() {
	        return "Beverage: " + name + " Size: " + size;
	    }

	    
	    public boolean equals(Object obj) {
	        if (this == obj) return true;
	        if (obj == null || getClass() != obj.getClass()) return false;
	        Beverage other = (Beverage) obj;
	        return name.equals(other.name) && type == other.type && size == other.size;
	    }

}

