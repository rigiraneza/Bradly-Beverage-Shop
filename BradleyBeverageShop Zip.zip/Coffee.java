
public class Coffee extends Beverage {
	
	    private boolean extraShot;
	    private boolean extraSyrup;

	    public Coffee(String name, Sizes size, boolean extraShot, boolean extraSyrup) {
	        super(name, Types.Coffee, size);
	        this.extraShot = extraShot;
	        this.extraSyrup = extraSyrup;
	    }

	    
	    public double calcPrice() {
	        double price = addSizePrice();
	        if (extraShot) price += 0.5;
	        if (extraSyrup) price += 0.5;
	        return price;
	    }

	    
	    public String toString() {
	        return super.toString() + (extraShot ? " + extra shot" : "") + (extraSyrup ? " + extra syrup" : "") + " | Price: $" + calcPrice();
	    }

}
