import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Order implements OrderInterface, Comparable<Order> {
	    private int orderNumber;
	    private Days orderDay;
	    private Customer customer;
	    private List<Beverage> beverages;

	    public Order(Days orderDay, Customer customer) {
	        this.orderDay = orderDay;
	        this.customer = new Customer(customer);
	        this.beverages = new ArrayList<>();
	        this.orderNumber = generateRandomOrderNumber();
	    }

	    private int generateRandomOrderNumber() {
	        Random random = new Random();
	        return 10000 + random.nextInt(80001);
	    }

	    public void addNewBeverage(String name, Sizes size, boolean extraShot, boolean extraSyrup) {
	        beverages.add(new Coffee(name, size, extraShot, extraSyrup));
	    }

	    public void addNewBeverage(String name, Sizes size, int numOfFruits, boolean proteinPowder) {
	        beverages.add(new Smoothie(name, size, numOfFruits, proteinPowder));
	    }

	    public void addNewBeverage(String name, Sizes size, boolean weekend) {
	        beverages.add(new Alcohol(name, size, weekend));
	    }

	    
	    public String toString() {
	        StringBuilder sb = new StringBuilder("Order #" + orderNumber + " | " + orderDay + "\n");
	        sb.append(customer).append("\n");
	        for (Beverage beverage : beverages) {
	            sb.append(beverage).append("\n");
	        }
	        return sb.toString();
	    }

	    
	    public int compareTo(Order other) {
	        return Integer.compare(this.orderNumber, other.orderNumber);
	    }

		@Override
		public boolean isWeekend() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public Beverage getBeverage(int itemNo) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void addNewBeverage(String bevName, Sizes size) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public double calcOrderTotal() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int findNumOfBeveType(Types type) {
			// TODO Auto-generated method stub
			return 0;
		}

		public double getTotalPrice() {
			// TODO Auto-generated method stub
			return 0;
		}


}
