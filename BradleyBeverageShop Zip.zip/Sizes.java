
public enum Sizes {

	Small, Medium, Large
}
