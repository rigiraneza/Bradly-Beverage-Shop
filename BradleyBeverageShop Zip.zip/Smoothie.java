
public class Smoothie extends Beverage{

	    private int numOfFruits;
	    private boolean proteinPowder;

	    public Smoothie(String name, Sizes size, int numOfFruits, boolean proteinPowder) {
	        super(name, Types.Smoothie, size);
	        this.numOfFruits = numOfFruits;
	        this.proteinPowder = proteinPowder;
	    }

	    
	    public double calcPrice() {
	        double price = addSizePrice() + numOfFruits * 0.5;
	        if (proteinPowder) price += 1.5;
	        return price;
	    }

	    
	    public String toString() {
	        return super.toString() + " | Fruits: " + numOfFruits + (proteinPowder ? " + Protein" : "") + " | Price: $" + calcPrice();
	    }

}
