
public enum Types {

	Coffee, Smoothie, Alcohol
	
}
